export const status = {
    th:{
        statusReport:'รายงานสถานะ',
    },
    en:{
        statusReport:'Status Report.'
    }
};