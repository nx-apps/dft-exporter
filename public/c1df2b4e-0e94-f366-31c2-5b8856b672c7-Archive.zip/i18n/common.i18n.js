export const common = {
    th:{
        foo:'ก',
        baa:'ข'
    },
    en:{
        foo:'a',
        baa:'b'
    }
};